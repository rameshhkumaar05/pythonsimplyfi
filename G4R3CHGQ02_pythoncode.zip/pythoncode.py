graph = {
    'Kiev': ['Prague'],
    'Prague': ['Zurich'],
    'Zurich': ['Amsterdam'],
    'Amsterdam': ['Barcelona'],
    'Barcelona': ['Berlin'],
    'Berlin': ['Kiev', 'Amsterdam'],
    'Paris': ['Skopje'],
    'Skopje': ['Paris']
}
def dfs(graph, start_city, visited, route):
    visited.add(start_city)
    route.append(start_city)
    for next_city in graph.get(start_city, []):
        if next_city not in visited:
            dfs(graph, next_city, visited, route)
    return route

def find_route(graph, start_city, cities_visited):
    visited = set()
    route = []
    dfs(graph, start_city, visited, route)
    if set(route) == set(cities_visited):
        return route
    else:
        return []  # return an empty list if the route is not found

start_city = 'Kiev'
cities_visited = ['Amsterdam', 'Kiev', 'Zurich', 'Prague', 'Berlin', 'Barcelona']
route = find_route(graph, start_city, cities_visited)
print(route)